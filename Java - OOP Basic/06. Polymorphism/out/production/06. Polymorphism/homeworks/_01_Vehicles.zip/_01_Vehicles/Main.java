package homeworks._01_Vehicles;

import homeworks._01_Vehicles.Models.Car;
import homeworks._01_Vehicles.Models.Truck;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] carInfo = reader.readLine().split("\\s+");
        double fuelQuantityCar = Double.valueOf(carInfo[1]);
        double fuelConsumptionInLitersPerKmCar = Double.valueOf(carInfo[2]);
        Car car = new Car(fuelQuantityCar, fuelConsumptionInLitersPerKmCar);

        String[] truckInfo = reader.readLine().split("\\s+");
        double fuelQuantityTruck = Double.valueOf(truckInfo[1]);
        double fuelConsumptionInLitersPerKmTruck = Double.valueOf(truckInfo[2]);
        Truck truck = new Truck(fuelQuantityTruck, fuelConsumptionInLitersPerKmTruck);

        int commandsCount = Integer.valueOf(reader.readLine());
        DecimalFormat df = new DecimalFormat("0.######");
        for (int i = 0; i < commandsCount; i++) {
            String[] commandInfo = reader.readLine().split("\\s+");
            String command = commandInfo[0];
            String vehicle = commandInfo[1];
            switch (command) {
                case "Drive":
                    if (vehicle.equals("Car")) {
                        double distance = Double.valueOf(commandInfo[2]);
                        if (car.canDriveDistance(distance)) {
                            System.out.println(String.format("Car travelled %s km", df.format(distance)));
                        } else {
                            System.out.println("Car needs refueling");
                        }
                    } else {
                        Double distance = Double.valueOf(commandInfo[2]);
                        if (truck.canDriveDistance(distance)) {
                            System.out.println(String.format("Truck travelled %s km", df.format(distance)));
                        } else {
                            System.out.println("Truck needs refueling");
                        }
                    }
                    break;
                case "Refuel":
                    if (vehicle.equals("Car")) {
                        double liters = Double.valueOf(commandInfo[2]);
                        car.refuelLiters(liters);
                    } else {
                        Double liters = Double.valueOf(commandInfo[2]);
                        truck.refuelLiters(liters);
                    }
                    break;
            }
        }

        System.out.println(String.format("Car: %.2f", car.getFuelQuantity()));
        System.out.println(String.format("Truck: %.2f", truck.getFuelQuantity()));
    }

}
