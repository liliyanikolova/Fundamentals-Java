package homeworks._01_Vehicles.Models;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumptionInLitersPerKm;
    private double travelledDistance;

    protected Vehicle(double fuelQuantity,
                   double fuelConsumptionInLitersPerKm,
                   double airConditionerFuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumptionInLitersPerKm = fuelConsumptionInLitersPerKm + airConditionerFuelConsumption;
        this.travelledDistance = 0;
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    public double getFuelConsumptionInLitersPerKm() {
        return fuelConsumptionInLitersPerKm;
    }

    public double getTravelledDistance() {
        return travelledDistance;
    }

    public boolean canDriveDistance(double distance){
        double neededFuelToDrive = this.fuelConsumptionInLitersPerKm * distance;
        if (neededFuelToDrive > this.fuelQuantity){
            return false;
        }

        this.fuelQuantity -= neededFuelToDrive;
        this.travelledDistance += distance;
        return true;
    }

    public void refuelLiters(double liters){
        this.fuelQuantity += liters;
    }
}
