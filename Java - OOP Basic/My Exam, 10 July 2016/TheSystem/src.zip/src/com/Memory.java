package com;

public class Memory {

}
