package com;

import java.util.Scanner;

public class _03_FormattingNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        double b = Double.parseDouble(scanner.nextLine());
        double c = Double.parseDouble(scanner.nextLine());

        System.out.print("|" + String.format("%-10X", a));
        System.out.print("|" + String.format("%10s", Integer.toBinaryString(a)).replace(" ", "0"));
        System.out.print("|" + String.format("%10.2f", b));
        System.out.print("|" + String.format("%-10.3f", c) + "|");
    }
}
